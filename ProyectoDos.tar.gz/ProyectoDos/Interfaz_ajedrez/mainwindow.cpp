#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->a1->setStyleSheet("background: url(:/images/torre.png) no-repeat center;");
    ui->b1->setStyleSheet("background: url(:/images/horse.png) no-repeat center;");
    ui->c1->setStyleSheet("background: url(:/images/alfil.png) no-repeat center;");
    ui->d1->setStyleSheet("background: url(:/images/rey.png) no-repeat center;");
    ui->e1->setStyleSheet("background: url(:/images/reina.png) no-repeat center;");
    ui->f1->setStyleSheet("background: url(:/images/alfil.png) no-repeat center;");
    ui->g1->setStyleSheet("background: url(:/images/horse.png) no-repeat center;");
    ui->h1->setStyleSheet("background: url(:/images/torre.png) no-repeat center;");
    ui->a2->setStyleSheet("background: url(:/images/peon.png) no-repeat center;");
    ui->b2->setStyleSheet("background: url(:/images/peon.png) no-repeat center;");
    ui->c2->setStyleSheet("background: url(:/images/peon.png) no-repeat center;");
    ui->d2->setStyleSheet("background: url(:/images/peon.png) no-repeat center;");
    ui->e2->setStyleSheet("background: url(:/images/peon.png) no-repeat center;");
    ui->f2->setStyleSheet("background: url(:/images/peon.png) no-repeat center;");
    ui->g2->setStyleSheet("background: url(:/images/peon.png) no-repeat center;");
    ui->h2->setStyleSheet("background: url(:/images/peon.png) no-repeat center;");


    ui->a8->setStyleSheet("background: url(:/images/torreb.png) no-repeat center;");
    ui->b8->setStyleSheet("background: url(:/images/horseb.png) no-repeat center;");
    ui->c8->setStyleSheet("background: url(:/images/alfilb.png) no-repeat center;");
    ui->d8->setStyleSheet("background: url(:/images/reyb.png) no-repeat center;");
    ui->e8->setStyleSheet("background: url(:/images/reinab.png) no-repeat center;");
    ui->f8->setStyleSheet("background: url(:/images/alfilb.png) no-repeat center;");
    ui->g8->setStyleSheet("background: url(:/images/horseb.png) no-repeat center;");
    ui->h8->setStyleSheet("background: url(:/images/torreb.png) no-repeat center;");
    ui->a7->setStyleSheet("background: url(:/images/peonb.png) no-repeat center;");
    ui->b7->setStyleSheet("background: url(:/images/peonb.png) no-repeat center;");
    ui->c7->setStyleSheet("background: url(:/images/peonb.png) no-repeat center;");
    ui->d7->setStyleSheet("background: url(:/images/peonb.png) no-repeat center;");
    ui->e7->setStyleSheet("background: url(:/images/peonb.png) no-repeat center;");
    ui->f7->setStyleSheet("background: url(:/images/peonb.png) no-repeat center;");
    ui->g7->setStyleSheet("background: url(:/images/peonb.png) no-repeat center;");
    ui->h7->setStyleSheet("background: url(:/images/peonb.png) no-repeat center;");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_2_clicked()
{

}

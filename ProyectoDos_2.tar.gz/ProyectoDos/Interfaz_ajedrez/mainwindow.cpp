#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    fichas[0]="background: url(:/images/torre.png) no-repeat center;";
    fichas[1]="background: url(:/images/horse.png) no-repeat center;";
    fichas[2]="background: url(:/images/alfil.png) no-repeat center;";
    fichas[3]="background: url(:/images/rey.png) no-repeat center;";
    fichas[4]="background: url(:/images/reina.png) no-repeat center;";
    fichas[5]="background: url(:/images/peon.png) no-repeat center;";
    fichas[6]="background: url(:/images/peon.png) no-repeat center;";

    fichas[7]="background: url(:/images/torreb.png) no-repeat center;";
    fichas[8]="background: url(:/images/horseb.png) no-repeat center;";
    fichas[9]="background: url(:/images/alfilb.png) no-repeat center;";
    fichas[10]="background: url(:/images/reyb.png) no-repeat center;";
    fichas[11]="background: url(:/images/peonb.png) no-repeat center;";

    ui->a1->setStyleSheet(fichas[0]);
    ui->b1->setStyleSheet(fichas[1]);
    ui->c1->setStyleSheet(fichas[2]);
    ui->d1->setStyleSheet(fichas[3]);
    ui->e1->setStyleSheet(fichas[4]);
    ui->f1->setStyleSheet(fichas[5]);



    conteo=0;
    posiact=0;
    posjact=0;
    posisig=1;
    posjsig=1;
    posimov=1;
    posjmov=1;

    pos[4]='\n';

    puerto=new QSerialPort();
    puerto->setPortName("/dev/ttyACM0");
    puerto->setBaudRate(9600);
    puerto->open(QIODevice::ReadWrite);


}



MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_2_clicked()
{

}

void MainWindow::on_a1_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=1;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=1;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }

    //Serial.readBytesUntil('\n');

}

void MainWindow::on_b1_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=2;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=2;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_c1_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=3;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=3;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_d1_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=4;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=4;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_e1_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=5;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=5;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_f1_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=6;
        posimov=posiact-posisig;
        posjmov=posjact-posjsig;

    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=6;
        posimov=posiact-posisig;
        posjmov=posjact-posjsig;
        conteo=0;
    }
}

void MainWindow::on_g1_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=7;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=7;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_h1_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=8;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=1;
        posjsig=8;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_a2_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=1;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=1;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_b2_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=2;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=2;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_c2_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=3;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=3;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_d2_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=4;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=4;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_e2_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=5;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=5;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_f2_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=6;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=6;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_g2_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=7;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=7;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_h2_clicked()
{

    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=8;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=2;
        posjsig=8;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_a3_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=1;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=1;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_b3_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=2;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=2;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_c3_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=3;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=3;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_d3_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=4;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=4;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_e3_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=5;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=5;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_f3_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=6;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=6;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_g3_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=7;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=7;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_h3_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=8;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=3;
        posjsig=8;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_a4_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=1;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=1;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_b4_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=2;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=2;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_c4_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=3;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=3;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_d4_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=4;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=4;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_e4_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=5;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=5;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_f4_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=6;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=6;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_g4_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=7;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=7;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_h4_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=8;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=4;
        posjsig=8;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_a5_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=1;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=1;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_b5_clicked()
{
    conteo++;


    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=2;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=2;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_c5_clicked()
{
    conteo++;


    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=3;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=3;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_d5_clicked()
{
    conteo++;


    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=4;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=4;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_e5_clicked()
{
    conteo++;


    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=5;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=5;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_f5_clicked()
{
    conteo++;


    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=6;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=6;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_g5_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=7;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=7;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_h5_clicked()
{
    conteo++;


    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=8;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=5;
        posjsig=8;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_a6_clicked()
{
    conteo++;


    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=1;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=1;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_b6_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=2;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=2;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_c6_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=3;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=3;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_d6_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=4;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=4;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_e6_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=5;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=5;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_f6_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=6;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=6;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_g6_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=7;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=7;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_h6_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=8;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=6;
        posjsig=8;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_a7_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=1;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=1;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_b7_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=2;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=2;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_c7_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=3;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=3;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_d7_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=4;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=4;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_e7_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=5;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=5;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_f7_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=6;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=6;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_g7_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=7;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=7;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_h7_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=8;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=7;
        posjsig=8;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_a8_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=1;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=1;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_b8_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=2;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=2;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_c8_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=3;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=3;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_d8_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=4;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=4;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_e8_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=5;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=5;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_f8_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=6;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=6;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_g8_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=7;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=7;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_h8_clicked()
{
    conteo++;

    if(conteo==1)
    {
        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=8;
        pos[0]=posiact-posisig;
        pos[1]=posjact-posjsig;


    }
    if(conteo==2)
    {

        posiact=posisig;
        posjact=posjsig;
        posisig=8;
        posjsig=8;
        pos[2]=posiact-posisig;
        pos[3]=posjact-posjsig;
        conteo=0;
        puerto->write(pos);

    }
}

void MainWindow::on_pushButton_4_clicked()
{
    puerto->open(QIODevice::ReadWrite);
}
